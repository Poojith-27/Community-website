
	<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class HomeController extends CI_Controller {

		public function __construct()
		{
			parent::__construct();
			if (!isset($_SESSION['username'])) {
				redirect(base_url());
			}
		}


		public function index()
		{


			$comments=$this->getcomments();
			$data['comments']=$comments;
			date_default_timezone_set("Asia/Kolkata");
			$created_at = Date("Y-m-d h-i-s");
			if (isset($_POST['btn_comment'])) {
				$post_id = $this->input->post("post_id");
				$comment = $this->input->post("comment");
				$this->addComment($post_id,$comment,$created_at);
				redirect(base_url("dashboard"));
			}

			if (isset($_POST['post_matter'])) {
				$data = array(
					"email" => $this->session->username,
					"matter" => $this->input->post("matter")
				);
				$this->db->insert("post_matter",$data);
				redirect("");
			}

			$post_matter = $this->db->get("post_matter")->result();

			$data['post_matter'] = $post_matter;
			$this->load->view('home',$data);
		}

		public function addComment($post_id,$comment,$created_at)
		{
			$data = array(
				"post_id" => $post_id,
				"comment" => $comment,
				"created_at" => $created_at,
				"by"=>$this->session->username
			);

			$this->db->insert("comment",$data);
			return true;

		}

		public function getComments()
		{
			$data = $this->db->get("comment")->result();
			return $data;
		}


	}

	?>
